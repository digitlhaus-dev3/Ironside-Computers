
import fs from 'fs/promises'
import path from 'path'

const TS_SCHEMA_FILENAME = 'schema.ts'
const JS_SCHEMA_FILENAME = 'schema.js'
const JSON_SCHEMA_FILENAME = 'schema.json'
const rootDir = '/home/ad.rapidops.com/yash.gohel/workspace/shogun/Ironside'
const srcDir = path.join(rootDir, 'src')
const sectionsSrcDir = path.join(srcDir, 'sections')
const generatedSchemaPath = path.join(srcDir, 'generated-schema.json')

const debugMode = process.env.ENABLE_SYNC_SCHEMA_DEBUG === 'true'

interface SectionSchema {
  props: Array<JSONObject>
}

type Schema = Record<string, SectionSchema>

interface JSONObject {
  [x: string]: JSONValue
}

type JSONValue = string | number | boolean | JSONObject | JSONArray

type JSONArray = Array<JSONValue>

interface Stats {
  sectionsCount: number
  succesfullyUpdatedCount: number
  failedToUpdateCount: number
  noSchemaFilesCount: number
  noUpdateNeededCount: number
}

export async function main() {
  try {
    const { schema, stats } = await getSchema()
    await writeSchema(schema, stats)

    return stats
  } catch(e) {
    console.error('failed to sync schema', e)
  }
}

main()

async function getSchema() {
  const stats: Stats = {
    sectionsCount: 0,
    succesfullyUpdatedCount: 0,
    failedToUpdateCount: 0,
    noSchemaFilesCount: 0,
    noUpdateNeededCount: 0,
  }

  let oldSchema = {}
  try {
    oldSchema = require(generatedSchemaPath)
    if (debugMode) console.log('old schema', oldSchema)
  } catch {
    if (debugMode) console.log('old not found', oldSchema)
  }

  if (debugMode) console.log('reading sections schemas from', sectionsSrcDir)
  const sectionsNames = await fs.readdir(sectionsSrcDir)
  stats.sectionsCount = sectionsNames.length

  const newSchema = {}

  for (const sectionName of sectionsNames) {
    const sectionDir = path.join(sectionsSrcDir, sectionName)
    const tsSchemaPath = path.join(sectionDir, TS_SCHEMA_FILENAME)
    const jsSchemaPath = path.join(sectionDir, JS_SCHEMA_FILENAME)
    const jsonSchemaPath = path.join(sectionDir, JSON_SCHEMA_FILENAME)
    const pathsToCheckForSchema = [tsSchemaPath, jsSchemaPath, jsonSchemaPath]

    let schemaPath = ''
    for (const currentSchemaPath of pathsToCheckForSchema) {
      if (await exists(currentSchemaPath)) {
        schemaPath = currentSchemaPath
        break
      }
    }

    if (!schemaPath) {
      stats.noSchemaFilesCount++
      if (debugMode) console.log('no schema file found for', sectionName)
      continue
    }

    let module
    try {
      module = require(schemaPath)
    } catch {}

    if (!module) {
      stats.failedToUpdateCount++
      if (debugMode) console.log('failed to load schema for', sectionName)
      continue
    }

    const sectionSchema = schemaPath === jsonSchemaPath ? module : module.schema

    if (!sectionSchema) {
      stats.failedToUpdateCount++
      console.warn(
        sectionName,
        'failed to load schema, please add named export for schema - export const schema = {...}',
      )
      continue
    }

    if (!isValidSchema(sectionSchema)) {
      stats.failedToUpdateCount++
      console.error(
        'Invalid schema found for',
        sectionName + '. Schema should have shape of { props: [] }',
      )
      continue
    }

    if (JSON.stringify(oldSchema[sectionName]) === JSON.stringify(sectionSchema)) {
      stats.noUpdateNeededCount++
      if (debugMode) console.log('unchanged schema for', sectionName)
    } else {
      stats.succesfullyUpdatedCount++
      if (debugMode) console.log('new schema for', sectionName)
    }

    newSchema[sectionName] = sectionSchema
  }

  return { schema: newSchema, stats }
}

async function writeSchema(schema: Schema, stats: Stats) {
  await fs.writeFile(generatedSchemaPath, JSON.stringify(schema, null, 2) + '\n')

  console.log('sections found:', stats.sectionsCount)
  console.log('- successfully updated:', stats.succesfullyUpdatedCount)
  console.log('- failed to update:', stats.failedToUpdateCount)
  console.log('- no schema changes detected:', stats.noUpdateNeededCount)
  console.log('- sections without schema file:', stats.noSchemaFilesCount)
}

async function exists(path: string) {
  try {
    await fs.access(path)
    return true
  } catch {
    return false
  }
}

function isValidSchema(schema: SectionSchema) {
  return typeof schema === 'object' && schema.props && Array.isArray(schema.props)
}
