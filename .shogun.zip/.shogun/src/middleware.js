import { NextResponse } from 'next/server'

  export async function middleware(request) {
    const proxyUrl = [{"path":"^/login.php","method":"POST"}].find((value, _index, _array) => {
      return new RegExp(value.path).test(request.nextUrl.pathname)
    })

    if (proxyUrl && request.method == proxyUrl.method) {
      let query =
        request.nextUrl.searchParams.toString() !== '' ? `?${request.nextUrl.searchParams}` : ''
      return NextResponse.rewrite(new URL(request.nextUrl.pathname + query, `https://ironside-dev-store.edge.frontend.getshogun.com`))
    } else {
      return NextResponse.next()
    }
  }
  