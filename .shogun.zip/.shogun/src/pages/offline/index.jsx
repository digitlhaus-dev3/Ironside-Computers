import React from 'react'
import PageHead from 'frontend-page-head'
import ErrorBoundary from 'ErrorReporting/SectionErrorBoundary'
import Offline from 'Components/Offline'

import { getDirectivesFromAPI } from '@getshogun/storefront-builder-nextjs/dist/components/directives'
import { logger, BuildError } from '@getshogun/storefront-logger'

const Page = ({ directives }) => {
  return (
    <>
      <PageHead siteDomain='ironside-dev-store.edge.frontend.getshogun.com' />
      <ErrorBoundary {...directives['9']} component={{ id: '26' }}>
        <Offline {...directives['9']} />
      </ErrorBoundary>
    </>
  )
}





export async function getStaticProps() {
  try {
    const pageId = 'offline-page'

    if (!pageId) {
      throw new Error('Unexpected Error: pageId is undefined')
    }

    const directives = await getDirectivesFromAPI(pageId)

    return {
      props: { directives },
    }
  } catch (err) {
    const error = new BuildError('Failed to get static props for page /offline', err)
    logger.error(error)
    throw error
  }
}



export default React.memo(Page)
