import React from 'react'
import Document, { Html, Head as NextHead, Main, NextScript, DocumentContext } from 'next/document'
import getConfig from 'next/config'
import { readFileSync } from 'fs'
import { join } from 'path'

import { Font } from '@getshogun/storefront-types'
import { Manifest, Icons, manifestFileName } from '@getshogun/storefront-builder-nextjs/dist/components/frontend-pwa'
import { Fonts } from '@getshogun/storefront-builder-nextjs/dist/components/frontend-fonts'
import { Preconnect } from '@getshogun/storefront-builder-nextjs/dist/components/Preconnect'
import { sortHead } from '@getshogun/storefront-builder-nextjs/dist/components/utils'

import site from '../../.temp/site.json'
import { getAssetPath } from '@getshogun/storefront-builder-nextjs/dist/components/utils'

interface DocumentFiles {
  sharedFiles: readonly string[]
  pageFiles: readonly string[]
  allFiles: readonly string[]
}

class CustomHead extends NextHead {
  getCssLinks(documentFiles: DocumentFiles) {
    if (config.storeFeatureFlags['sites.criticalCSS']) {
      return super.getCssLinks(documentFiles)
    }

    const { allFiles } = documentFiles
    if (!allFiles || allFiles.length === 0) return null

    return allFiles
      .filter((file) => /.css$/.test(file))
      .map((file) => (
        <style
          key={file}
          data-href={`/.next/${file}`}
          dangerouslySetInnerHTML={{
            __html: readFileSync(join(process.cwd(), '.next', file), 'utf-8'),
          }}
        />
      ))
  }

  render() {
    if (this.context.head) {
      this.context.head = sortHead(this.context.head)
    }

    return super.render()
  }
}

const { publicRuntimeConfig: config } = getConfig()

const partytownEnabled = config.storeFeatureFlags['sites.partytown']

/**
 * A helper function for defining partytown config that accepts overrides
 *
 * Note: This is used inside user defined snippets!
 */
function getPartytownConfig(overrides?: unknown): string {
  let ptownConfig = { lib: config.partytown.libPath, swPath: config.partytown.swPath }

  if (typeof overrides === 'object') {
    ptownConfig = { ...ptownConfig, ...overrides }
  }

  return JSON.stringify(ptownConfig)
}

function getPartytownScript() {
  if (!partytownEnabled) return null

  return (
    <script
      data-partytown-config
      dangerouslySetInnerHTML={{
        __html: `partytown = ${getPartytownConfig()}`,
      }}
    />
  )
}

// We want to use NextJS default of loading styles if critical css is enabled
// const Head = config.storeFeatureFlags['sites.criticalCSS'] ? HeadWithoutStyles : HeadWithStyles

interface DocumentProps {
  pathname: string
  fonts: Font[]
  themeColor: string
  appName: string
  browserConfigPath: string
  manifestPath: string
  siteIcon: string
  assetsCdnOrigin: { href: string }
}

class StorefrontDocument extends Document<DocumentProps> {
  static async getInitialProps(ctx: DocumentContext) {
    const initialProps = await Document.getInitialProps(ctx)

    return {
      ...initialProps,
      fonts: site.fonts,
      themeColor: site.manifest.themeColor,
      appName: site.manifest.name,
      browserConfigPath: getAssetPath('browserconfig.xml'),
      manifestPath: getAssetPath(manifestFileName),
      siteIcon: site.icon,
      assetsCdnOrigin: { href: process.env.NEXT_PUBLIC_ASSETS_CDN_ORIGIN || '' },
    }
  }

  render() {
    return (
      <Html lang={site.defaultLocale} dir="ltr">
        <CustomHead>
          <meta httpEquiv="X-UA-Compatible" content="ie=edge" />

          <meta name="theme-color" content={this.props.themeColor} />
          <meta name="mobile-web-app-capable" content="yes" />
          <meta name="application-name" content={this.props.appName} />

          {/* Apple */}
          <meta name="apple-mobile-web-app-capable" content="yes" />
          <meta name="apple-mobile-web-app-status-bar-style" content="default" />
          <meta name="apple-mobile-web-app-title" content="Store" />

          {/* Microsoft */}
          <meta name="msapplication-TileColor" content={this.props.themeColor} />
          <meta name="msapplication-config" content={this.props.browserConfigPath} />

          <Preconnect origins={[this.props.assetsCdnOrigin]} />
          <Manifest href={this.props.manifestPath} />
          <Icons icon={this.props.siteIcon} />
          <Fonts fonts={this.props.fonts} />
          {/* we set default config here but this will be overwritten if one is specified in snippets */}
          {getPartytownScript()}
          {/* <--HEAD SNIPPETS START-bdba7ab0--> */}
{/* <--HEAD SNIPPETS END-bdba7ab0--> */}
        </CustomHead>
        <body>
          <Main />
          <NextScript />
          {/* <--BODY SNIPPETS START-bdba7ab0--> */}
{/* <--BODY SNIPPETS END-bdba7ab0--> */}
        </body>
      </Html>
    )
  }
}

export default StorefrontDocument