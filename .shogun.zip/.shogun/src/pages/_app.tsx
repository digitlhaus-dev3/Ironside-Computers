
import React from 'react'
import getConfig from 'next/config'
import { CustomerProvider } from 'frontend-customer'
import { CartProvider } from 'frontend-checkout'
import { PlatformApiType, StoreConfig, SupportedPlatform } from 'frontend-checkout/dist/types'
import { StoreProvider } from 'frontend-store'
import { registerServiceWorker } from '@getshogun/storefront-builder-nextjs/dist/components/frontend-pwa'
import { lazyLoadingPolyfill } from 'frontend-ui'
import { AppProps } from 'next/app'

import App from 'Components/App'

import inventory from '../../.temp/inventory.json'
import '../global.css'

const { publicRuntimeConfig: config } = getConfig()
const storeId = config.storeId || ''
const platform = (config.storePlatform || '') as SupportedPlatform
const storePlatformApiType = (config.storePlatformApiType || '') as PlatformApiType
const storeToken = config.storeToken || ''
const storeDomain = config.storePlatformPublicDomain || ''
const storePlatformDomain = config.storePlatformDomain || ''
const storeName = config.storeName || ''
const sharedCheckoutDomains: string[] = config.storeSharedCheckoutDomains || []
const isInventoryJSONDisabled = config.storeFeatureFlags['sites.disable_product_inventory_json']
const enableInventoryPlatformApi = config.storeFeatureFlags['sites.enable_inventory_platform_api']
const releaseVersion = config.releaseVersion || ''

const platformConfig = {
  shopify: {
    storeToken,
    storeDomain,
    storePlatformDomain,
  },
  big_commerce: null,
  magento: null,
}[platform]

interface FrontendAppProps {
  inventory: unknown
}

// In LDE we're loading directives on fetch upon clone
// Also in the future we'll be fetching directly from CMS
// There we need this environment variable to prevent page
// from being in constant loading
// In other words, we're not loading the directives in parallel in LDE
process.env.DIRECTIVES_LOADED = 'true'

function MyApp({ Component, pageProps }: AppProps) {
  // storage value can override the site.platformApiType which we use for testing purposes.
  const platformApiType =
    (typeof window !== 'undefined' &&
      (localStorage.getItem('shogun.site.platformApiType') as PlatformApiType)) ||
    storePlatformApiType

  React.useEffect(() => {
    registerServiceWorker(releaseVersion)
    lazyLoadingPolyfill()
  }, [])

  return (
    <div id="frontend-root">
      <CustomerProvider
        config={{
          storeId,
          // This is needed to make types compatible with older versions of frontend-customer package (e.g. 1.9.1).
          // We can remove this after we migrate all customer to 2.0.3 or above
          platform: platform as 'shopify' | 'big_commerce',
          platformApiType,
          platformConfig,
        }}
      >
        <CartProvider
          platform={platform}
          storeConfig={
            {
              storePlatformDomain,
              storeDomain,
              storeToken,
              storeName,
              storeId,
              platformApiType,
              sharedCheckoutDomains,
              inventory,
              isInventoryJSONDisabled,
              enableInventoryPlatformApi,
            } as StoreConfig
          }
        >
          <StoreProvider>
            <App>
              <Component {...pageProps} />
            </App>
          </StoreProvider>
        </CartProvider>
      </CustomerProvider>
    </div>
  )
}

export default MyApp;

