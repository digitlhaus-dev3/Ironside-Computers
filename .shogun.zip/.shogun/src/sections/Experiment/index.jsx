import React from 'react'

import './styles.css'

const Component = ({ product, category }) => (
  <div>
    <h2>{product ? 'product' : 'category'}:</h2>
    <pre>{JSON.stringify(product || category, null, 4)}</pre>
  </div>
)

export default Component