import { Box, Button, Container, Divider, Input, Text } from '@chakra-ui/react'
import Heading from 'Components/Heading'
import HStack from 'Components/HStack'
import React from 'react'


const AccountDetails = () => {
  return (
    <div className="backgroundColor">
      <HStack justify="space-between" mb={12}>
        <Heading as="h1">My Account</Heading>
        <Button variant="outline" size="sm">
          Account Details
        </Button>
        <Button variant="outline" size="sm">
          Order History
        </Button>
      </HStack>
      <Divider my={2}></Divider>
      <div>
        <HStack justify="space-between" mb={12}>
          <Heading as="h3">Personal Details</Heading>
          <Box maxW="sm" borderWidth="1px" borderRadius="lg" overflow="hidden">
            <Text fontSize="xs">
              Name
              <Text fontSize="xs">John</Text>
            </Text>
            <Text fontSize="xs">
              Last Name
              <Text fontSize="xs">Bigbootay</Text>
            </Text>
            <Text fontSize="xs">
              Email
              <Text fontSize="xs">ohlawd@thicc.com</Text>
            </Text>
            <Text fontSize="xs">
              Phone
              <Text fontSize="xs">(616)600-65555</Text>
            </Text>
            <Button variant="outline" size="sm">
              Update
            </Button>
            <img src="https://i.ibb.co/Js4k8hR/user.png" />
          </Box>
          <Box maxW="sm" borderWidth="1px" borderRadius="lg" overflow="hidden">
            <Text fontSize="xs">
              Current Password
              <Input variant="flushed" />
            </Text>
            <Text fontSize="xs">
              New Password
              <Input variant="flushed" />
            </Text>
            <Text fontSize="xs">
              Confirm New Password
              <Input variant="flushed" />
            </Text>
            <Button variant="outline" size="sm">
              Update
            </Button>
            <img src="https://i.ibb.co/3S2m69T/Lock-1.png" />
          </Box>
        </HStack>
        <HStack justify="space-between" mb={12}>
          <Heading as="h3">Shipping Address</Heading>
          <Box maxW="sm" borderWidth="1px" borderRadius="lg" overflow="hidden">
            <Text fontSize="xs">
              Name
              <Text fontSize="xs">John</Text>
            </Text>
            <Text fontSize="xs">
              Last Name
              <Text fontSize="xs">Bigbootay</Text>
            </Text>
            <Text fontSize="xs">
              Addres
              <Text fontSize="xs">ohlawd@thicc.com</Text>
            </Text>
            <Text fontSize="xs">
              Address Line 2<Text fontSize="xs">(616)600-65555</Text>
            </Text>
            <Button variant="outline" size="sm">
              Update
            </Button>
            <img src="https://i.ibb.co/k05m4wV/truck-1-1.png" />
          </Box>
          <Heading as="h3">Billing Address</Heading>
          <Box maxW="sm" borderWidth="1px" borderRadius="lg" overflow="hidden">
            <Text fontSize="xs">
              Name
              <Text fontSize="xs">John</Text>
            </Text>
            <Text fontSize="xs">
              Last Name
              <Text fontSize="xs">Bigbootay</Text>
            </Text>
            <Text fontSize="xs">
              Addres
              <Text fontSize="xs">ohlawd@thicc.com</Text>
            </Text>
            <Text fontSize="xs">
              Address Line 2<Text fontSize="xs">(616)600-65555</Text>
            </Text>
            <Button variant="outline" size="sm">
              Update
            </Button>
            <img src="https://i.ibb.co/XD9xpVz/Credit-card-3-1.png" />
          </Box>
        </HStack>
      </div>
    </div>
  )
}

export default AccountDetails
