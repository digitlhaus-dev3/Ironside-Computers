import React from 'react'
    import styles from './styles.module.css'

    const Offline = ({ title, text }) => {
      React.useEffect(() => {
        const title = document.querySelector('title')
        if (title) title.innerText = 'Offline'
      }, [])

      return (
        <div className={styles['Offline-container']}>
          <h1>{title}</h1>
          <p>{text}</p>
        </div>
      )
    }
    export default Offline