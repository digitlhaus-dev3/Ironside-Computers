import React from 'react'
import Head from 'frontend-head'

const PageMeta = ({ title, description, url }) => {
  return (
    <Head>
      {title && <title>{title}</title>}
      {description && <meta name="description" content={description} />}
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      {url && <link rel="canonical" href={url} key="canonicalURL" />}
    </Head>
  )
}
export default PageMeta
