import React from 'react'
import Head from 'frontend-head'
import { useCartActions } from 'frontend-checkout'
import { useRouter } from 'next/router'
import { Script } from '@getshogun/frontend-components'

const Component = ({ html, scripts, fonts }) => {
  const { addItems } = useCartActions()
  const parsedScripts = JSON.parse(scripts || '[]')
  const parsedFonts = JSON.parse(fonts || '[]')
  const router = useRouter()

  if (!html) {
    throw new Error('HTML prop not provided')
  }

  React.useEffect(() => {
    function routeChangeListener(url, { shallow }) {
      const event = new Event('pagebuilder:load', { bubbles: true, cancelable: true })
      document.dispatchEvent(event)
    }

    /**
* @param {SubmitEvent} event
*/
function cartActionListener(event) {
  const formAction = event.target.getAttribute('action')
  const isCartAction = /^\/cart\.php/.test(formAction)

  if (!isCartAction) return

  event.preventDefault()
  event.stopImmediatePropagation()

  const formData = Object.fromEntries(new FormData(event.target))
  const { action, product_id } = formData
  const qty = formData['qty[]']
  const optionSelections = []

  for (const field in formData) {
    if (/^attribute/.test(field)) {
      let optionId = Number(field.split(/[[]]/)[1])
      let optionValue = Number(formData[field])

      optionSelections.push({ optionId: optionId, optionValue: optionValue })
    }
  }

  switch (action) {
    case 'add': {
      addItems({
        id: Number(product_id),
        quantity: Number(qty) || 1,
        optionSelections: optionSelections
      })
      break
    }
    default: {
      console.warn(`Unhandled action - ${action}`, event)
    }
  }
}

document.addEventListener('submit', cartActionListener, { capture: true })
router.events.on('routeChangeComplete', routeChangeListener)

return () => {
  document.removeEventListener('submit', cartActionListener)
  router.events.off('routeChangeComplete', routeChangeListener)
}

  }, [])

  const headScripts = parsedScripts
    .filter(({ location }) => location === 'head')
    .map(({ src, inline }) => <Script key={src} src={src} strategy="beforeInteractive">{inline}</Script>)

  const bodyScripts = parsedScripts
    .filter(({ location }) => location === 'body')
    .map(({ src, inline }) => <Script key={src} src={src}>{inline}</Script>)

  const fontLinks = parsedFonts.map(src => <link rel="stylesheet" type="text/css" href={src}/>)

  return (
    <>
      <Head>
        <link rel="preconnect" href="https://fonts.googleapis.com"/>
        <link rel="preconnect" href="https://fonts.gstatic.com"/>
        <link rel="preconnect" href="https://cdn.getshogun.com"/>
        <link rel="preconnect" href="https://cdn-staging.getshogun.com"/>
        <link rel="preconnect" href="https://i.shgcdn.com"/>
        {fontLinks}
      </Head>
      {headScripts}
      <div className="page-builder-page" dangerouslySetInnerHTML={{__html: html}} style={{width: "100%"}} />
      {bodyScripts}
    </>
  )
}

export default Component
