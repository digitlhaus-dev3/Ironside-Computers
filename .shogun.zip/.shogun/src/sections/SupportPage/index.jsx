/**
 *
 * MIT License
 *
 * Copyright 2021 Shogun, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom
 * the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
import * as React from 'react'
import { Box, Container as ChakraContainer, forwardRef, useStyleConfig } from '@chakra-ui/react'
import Heading from 'Components/Heading'
import Divider from 'Components/Divider'
import Flex from 'Components/Flex'
import Text from 'Components/Text'
import VStack from 'Components/VStack'
import Container from 'Components/Container'
import FormLabel from 'Components/FormLabel'
import FormControl from 'Components/FormControl'
import Button from 'Components/Button'
import Grid from 'Components/Grid'
import Input from 'Components/Input'

/**
 * @typedef { import("@chakra-ui/react").ContainerProps } ChakraContainerProps
 * @typedef {{
 *  variant?: 'solid' | 'outline' | 'section-wrapper' | 'section-wrapper-centered',
 *  constrainContent?: boolean
 *  centerContent?: boolean
 *  children?: React.ReactNode
 * }} ContainerProps
 */
const SupportPage = forwardRef(
  (
    /** @type {ContainerProps & ChakraContainerProps }*/
    props,
    /** @type {React.LegacyRef<HTMLDivElement>} */
    ref,
  ) => {
    const { variant, centerContent, constrainContent, children, ...rest } = props
    const title = 'Support Page'

    let styles = useStyleConfig('ShogunContainer', { variant })

    if (constrainContent) {
      return (
        <ChakraContainer ref={ref} sx={styles} centerContent {...rest}>
          {children}
        </ChakraContainer>
      )
    }
    const para = `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.`

    if (centerContent) {
      styles = { ...styles, display: 'flex', flexDirection: 'column', alignItems: 'center' }
    }

    return (
      <>
        <Heading as="h3" color="black" fontWeight="semibold" size="lg">
          {title}
        </Heading>
        <Divider my="4" borderBottomWidth="1px" />
        <Box ref={ref} sx={styles} {...rest}>
          <Flex alignItems="left" bg="gray.100" justifyContent="space-between" p="4">
            <Text>
              <Heading as="h4" color="black" size="sm">
                Join the team!
              </Heading>
              {para}
            </Text>
            <VStack spacing="0">
              <Heading as="h4" color="black" size="sm">
                Sponsorship Application
              </Heading>
              <Grid as="form" w={{ base: 'full', md: 'md' }} rowGap={5}>
                <Container as={FormControl} id="register-first-name">
                  <FormLabel>First name </FormLabel>
                  <Input />
                </Container>
                <Container as={FormControl} id="register-last-name">
                  <FormLabel>Last name </FormLabel>
                  <Input />
                </Container>
                <Container as={FormControl} id="register-email-name">
                  <FormLabel>
                    Email Address{' '}
                    <Text as="span" color="gray.400" fontSize="xs">
                      (optional)
                    </Text>
                  </FormLabel>
                  <Input />
                </Container>
                <Container as={FormControl} id="register-link">
                  <FormLabel>
                    Link to Social Media{' '}
                    <Text as="span" color="gray.400" fontSize="xs">
                      (optional)
                    </Text>
                  </FormLabel>
                  <Input />
                </Container>
                <Button loadingText="Saving..." type="submit" width="48">
                  Submit
                </Button>
              </Grid>
            </VStack>
          </Flex>
        </Box>
      </>
    )
  },
)

export default SupportPage
