importScripts('./workbox-v6.4.2/workbox-sw.js')
workbox.setConfig({ modulePathPrefix: './workbox-v6.4.2' })

const OFFLINE_HTML_PAGE = 'offline.html'

self.skipWaiting()
workbox.core.clientsClaim()

// Precache js, css, offline html and webmanifest files
workbox.precaching.precacheAndRoute([{"revision":null,"url":"manifest.webmanifest"}])

// Cache html files for 30 days with Network first strategy.
// Skip any proxy pages.
workbox.routing.registerRoute(
  ({ event }) =>
    Boolean(
      event.request.destination === 'document' && !new URL(event.request.url).pathname.match(/(^\/v3\/carts.*)|(^\/v3\/customers.*)|(^\/v3\/checkouts.*)|(^\/v3\/catalog\/products.*.*)|(^\/v2\/orders.*)|(^\/account.php.*)|(^\/graphql.*)|(^\/api\/storefront.*)|(^\/remote\/v1.*)|(^\/login.php\nPOST)|(^\/checkout.*)|(^\/internalapi.*)|(^\/cart.php.*)|(^\/remote-checkout.*)/),
    ),
  new workbox.strategies.NetworkFirst({
    cacheName: 'htmls',
    plugins: [
      new workbox.expiration.ExpirationPlugin({
        maxAgeSeconds: 60 * 60 * 24 * 30, // 30 days
      }),
      new workbox.precaching.PrecacheFallbackPlugin({
        fallbackURL: OFFLINE_HTML_PAGE,
      }),
    ],
  }),
)

// Cache icons for 365 days with Cache first strategy
workbox.routing.registerRoute(
  ({ sameOrigin, event }) => {
    return sameOrigin && event.request.url.match(/\.(?:png|ico)$/)
  },
  new workbox.strategies.CacheFirst({
    cacheName: 'icons',
    plugins: [
      new workbox.expiration.ExpirationPlugin({
        maxAgeSeconds: 60 * 60 * 24 * 365, // 365 days
      }),
    ],
  }),
)

// Cache Google fonts stylesheets with Stale while revalidate strategy
workbox.routing.registerRoute(
  /^https:\/\/fonts\.googleapis\.com/,
  new workbox.strategies.StaleWhileRevalidate({
    cacheName: 'google-fonts-stylesheets',
  }),
)

// Cache fonts for 365 days with Cache first strategy
workbox.routing.registerRoute(
  ({ event }) => event.request.destination === 'font',
  new workbox.strategies.CacheFirst({
    cacheName: 'fonts',
    plugins: [
      new workbox.cacheableResponse.CacheableResponsePlugin({
        statuses: [0, 200],
      }),
      new workbox.expiration.ExpirationPlugin({
        maxAgeSeconds: 60 * 60 * 24 * 365, // 365 days
        maxEntries: 30,
      }),
    ],
  }),
)

// Custom error handler
workbox.routing.setCatchHandler(() => Response.error())

self.addEventListener('fetch', (event) => {
  if (/\/amazonpay\/payment\-session/.test(event.request.url)) {
    event.respondWith(fetch(event.request.url, { credentials: 'include' }))
  }
})
