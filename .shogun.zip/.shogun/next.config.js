const fs = require('fs')
const path = require('path')
const withPlugins = require('next-compose-plugins')
const { withFrontend } = require(path.resolve('/home/ad.rapidops.com/yash.gohel/workspace/shogun/Ironside', 'node_modules/@getshogun/storefront-builder-nextjs/dist/components/next-plugin-frontend'))

const { getStorefrontPath, parseSWCConfigFromFlags } = require(path.resolve('/home/ad.rapidops.com/yash.gohel/workspace/shogun/Ironside', 'node_modules/@getshogun/storefront-builder-nextjs/dist/components/utils'))

const storefrontPath = getStorefrontPath('/home/ad.rapidops.com/yash.gohel/workspace/shogun/Ironside/.shogun')

const store = JSON.parse(fs.readFileSync(storefrontPath.temp.site))
const flags = JSON.parse(fs.readFileSync(storefrontPath.temp.flags))

const swcConfig = parseSWCConfigFromFlags(flags)

const releaseVersion = process.env.RELEASE_VERSION

let assetPrefix = undefined

delete process.env['NODE_ENV']
delete process.env['NEXT_BUILDER_CPUS']

const withTM = require("next-transpile-modules")([
  "@getshogun/storefront-builder-nextjs",
  "@getshogun/frontend-components",
  "@getshogun/frontend-hooks",
]);

const nextConfig = {
  rewrites() {
    return store.proxyUrls
      .concat("data/productInventory.json", "pushowl.*")
      .filter((url) => !url.includes("(") && !url.includes("\n"))
      .map((url) => ({
        source: `/:path(${url.replace("^/", "")})`,
        destination: `https://${store.domain}/:path`,
      }));
  },
  webpack(config) {
    config.resolve.alias = {
      ...config.resolve.alias,
      "frontend-config": require.resolve(
        "@getshogun/storefront-builder-nextjs/dist/components/frontend-config"
      ),
    };
    return config;
  },
};

module.exports = async (phase) =>
  withPlugins(
    [
      withTM, // withTM needs to be last plugin that does compilation
      withFrontend({
        flags,
        store,
        releaseVersion,
        assetPrefix,
        typecheck: false,
        lint: false,
        partytown: flags["sites.partytown"] || false,
        criticalCSS: flags["sites.criticalCSS"] || false,
        swcMinify: swcConfig.minify,
      }),
    ],
    nextConfig
  )(phase, { defaultConfig: {} });
